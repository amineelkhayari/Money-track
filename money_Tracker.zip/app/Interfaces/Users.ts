
export const monthNames = [
  {
    ID: 1,
    Value: "January"
    
  },
  {
    ID: 2,
    Value: "February"
  },
  {
    ID: 3,
    Value: "March"
  },
  {
    ID: 4,
    Value: "April"
  },
  {
    ID: 5,
    Value: "May"
  },
  {
    ID: 6,
    Value: "June"
  },
  {
    ID: 7,
    Value: "July"
  },
  {
    ID: 8,
    Value: "August"
  },
  {
    ID: 9,
    Value: "September"
  },
  {
    ID: 10,
    Value: "October"
  },
  {
    ID: 11,
    Value: "November"
  },
  {
    ID: 12,
    Value: "December"
  },
  
];
export const users:Participants[]  = [
    {
        ID: 1,
        Value: "Amine",
        checked: false,
        Payed: false
      },
      {
        ID: 2,
        Value: "Mohammed",
        checked: false,
        Payed: false
      },
      {
        ID: 3,
        Value: "Jounir",
        checked: false,
        Payed: false
      },
      {
        ID: 4,
        Value: "Harari",
        checked: false,
        Payed: false,
      }
  ];
  